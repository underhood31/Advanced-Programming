public class Sum {
private int var1, var2;
public Sum(int v1, int v2) {var1=v1; var2=v2;}
public int sum () {
return var1 + var2;
}
}