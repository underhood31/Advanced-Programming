import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
//@RunWith(JUnitPlatform.class)

@Suite.SuiteClasses({
	ExceptionTest.class,
	SerializationTest.class

})
public class TestSuit {
	
}
